package com.example.gestures;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

    public static final int SWIPE_THRESHOLD = 100;
    public static final int SWIPE_VELOCITY_THRESHOLD = 100;
    private ConstraintLayout clo;
    private GestureDetector gestureDetector;
    public Boolean isWhite;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        clo = findViewById(R.id.Clo);

        gestureDetector = new GestureDetector(this);

    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent downEvent, MotionEvent moveEvent, float vX, float vY) {
        boolean result = false;
        float dY = moveEvent.getY() - downEvent.getY();
        float dX = moveEvent.getX() - downEvent.getX();

        if(Math.abs(dX) > Math.abs(dY))
        {
            if(Math.abs(dX) > SWIPE_THRESHOLD && Math.abs(vX) > SWIPE_VELOCITY_THRESHOLD)
            {
                if(dX > 0)
                {
                    onSwipeRight();
                }
                else
                    {
                    onSwipeLeft();
                    }
            }
        }
        else
        {
            if(Math.abs(dY) > SWIPE_THRESHOLD && Math.abs(vY) > SWIPE_VELOCITY_THRESHOLD)
            {
                if (dY > 0)
                {
                    onSwipeBottom();
                }
                else
                {
                    onSwipeTop();
                }
            }

        }

        return true;
    }

    private void onSwipeTop()
    {
        clo.setBackgroundColor(0xFF0000FF);
        isWhite = false;
    }

    private void onSwipeBottom()
    {
        clo.setBackgroundColor(0xFF000047);
        isWhite = false;
    }

    private void onSwipeRight()
    {
        clo.setBackgroundColor(0xFFFF0000);
        isWhite = false;
    }

    private void onSwipeLeft()
    {
        clo.setBackgroundColor(0xFF470000);
        isWhite = false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e)
    {
            if (isWhite = false) {
                clo.setBackgroundColor(0xFFFFFFFF);
                isWhite = true;
            }
            if (isWhite = true) {
                clo.setBackgroundColor(0xFF000000);
                isWhite = false;
            }
            return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {

        return false;
    }
}
